module Private
  def self.table_name_prefix
    'private_'
  end
end
