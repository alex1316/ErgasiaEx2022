$('.contact-user').replaceWith('<div>Message has not been sent</div>');
