require 'rails_helper'

RSpec.describe Private::ConversationsController, type: :controller do

end
