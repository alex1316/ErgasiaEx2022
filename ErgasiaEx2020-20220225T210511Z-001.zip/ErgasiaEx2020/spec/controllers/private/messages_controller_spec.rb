require 'rails_helper'

RSpec.describe Private::MessagesController, type: :controller do

end
