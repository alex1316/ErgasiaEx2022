FactoryBot.define do
  factory :post do
    title { "aaaaaaaaaaaaaaaaaaaa" }
    content { "aaaaaaaaaaaaaaaaaaaa" }
    user
    category
  end
end
