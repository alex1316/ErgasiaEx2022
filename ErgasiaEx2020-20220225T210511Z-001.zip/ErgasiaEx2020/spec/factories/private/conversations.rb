FactoryBot.define do
  factory :private_conversation, class: 'Private::Conversation' do
    
  end
end
