FactoryBot.define do
  factory :private_message, class: 'Private::Message' do
    
  end
end
